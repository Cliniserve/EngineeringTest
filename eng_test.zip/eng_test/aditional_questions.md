### How long did you spend on the coding test? What would you add to your solution if you had more time?
The assessment took about 5 to 6 hours to be completed divided in the folowing way:
- into over 1 hour in analysis, planning and design
- 3 to 4 hours implementation
- over 1 hour testing.

* If more time would be provided the current task could be improved as Followed:
- Use Redux in order to have all states centralized, immutable, predictable and traceable.
- Use Enzyme in order to test all the UI Components
- Use docker to host the RKI-API server due to hight traffic on the RKI server.


### What alternative approaches/solutions to the user story did you consider when engineering your solution?
As a first step was considered the posibility to show in diferents views the sources requested (cases/incidence), depending in the selection of the users, what could be a more organized way to display the requested information and from performance point of view would allow to make one request at the time to the RKI-API.

### What benefits/downsides would they have had compared to the selected solution?
How ever the idea of displaying all souces at the same place could bring the possibility to show a correspondency beetween sources and compare them.

### What additional features/improvements do you think could help the customer gain more value from your application?

As improvements the following features would add value to the solution:
- Add searching and sorting functionalities
- Add possibility of searching by other Districts AGS
- Implement pagination, taking into consideration that case when the period of time requested would be extensive
- Give the user the posibility of adding or deleting sources depending in what would the user like to see
- Add graphics that allow the user to visualize and compare several sources  

### Where do you see issues in your code that might cause issues in the future? How would you monitor the performance of your app?
- Not enought testing for different side cases.
- Not enought error handling

### How would you improve the API that you just used or its documentation?
Api could have extra features like:
- posibility to filter sources by period of time, by week, month, year

### What did you think about this test? How interesting was it for you? How would you recommend us to improve the test?
The test was really interesting and well structured, the description of the User History was really clear and the steps to follow, in general an organized assessment.