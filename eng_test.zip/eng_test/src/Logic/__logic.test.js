import { requestData } from "./logic";

describe('Fetch data from RKI-API',()=>{
  test('Fetch data with ramdom number of days beetween 1 and 100',async()=>{
    const days = Math.floor(Math.random() * 100) + 1
    const resp = await requestData(days);
    const checkMatch = obj => !!obj.date && !!obj.cases && !!obj.incidence; 
    expect(resp.length).toEqual(days);
    expect(resp.every(checkMatch)).toBeTruthy();    
  });
  test('Fetch without limit provided',async()=>{
    const resp = await requestData(0);
    expect(resp.length).toEqual(0);
    expect(resp).toEqual([]);
  })
})