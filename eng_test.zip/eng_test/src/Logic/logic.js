import axios from "axios";
import { RKI_API_ROUTES } from './RKI-API-routes.json';

const getResponseHistoryData = response =>  response.data.data['09162'] ? response.data.data['09162'].history:[];
const getCases = filter => axios.get(RKI_API_ROUTES.GET_CASES_PER_DAY + filter).then(getResponseHistoryData);
const getIncidence = (filter) => axios.get(RKI_API_ROUTES.GET_INCIDENCE_PER_DAY + filter).then(getResponseHistoryData);
  
const processrequestedData = (data, filter) => {  
  const processedData = [];
  const [cases, incidence] = data;
  if((cases && cases.length > 0) && (incidence && incidence.length > 0)){
    for (let index = 0; index < filter; index++) {    
      processedData.push({
        date: new Date(cases[index].date).toLocaleString(),
        cases: cases[index].cases,
        incidence: Math.round(incidence[index].weekIncidence * 100) / 100
      });    
    }
  }  
  return processedData;
}

const requestData = filter => 
  Promise.all([getCases(filter), getIncidence(filter)])
  .then(result=>processrequestedData(result, filter))
  .catch(error=>{
    throw new Error('Error while getting RKI-API data: '+error);
  }); 
 

export { requestData };