import React from "react";
import './header.css';

const HeaderView = ({ onFilterChange, startLoading }) => (
    <div className='header-component'>
      <div className='header-component__title'>
        <img src='bayern_logo.png' />
        <div>
          <span>Corona Statistics</span>
          <span>Munich, Bavaria</span>
        </div>
      </div>
      <div className='header-component__filter'>
        Filter by last        
        <select 
          onChange={e => {
            startLoading();
            onFilterChange(e.currentTarget.value);                     
          }}
        >
          <option value={0}>---</option>
          <option value={30}>30</option>
          <option value={60}>60</option>
          <option value={90}>90</option>
        </select>
        days
      </div>
    </div>
  );


export default HeaderView;