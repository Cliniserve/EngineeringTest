import React from "react";
import './table.css';

const TableHeader = () => (
  <div className="table-component__header">
    <div className="table-component__cell--sm"/>     
    <div className="table-component__cell">
      Date
    </div>
    <div className="table-component__cell--sm">
        Cases
    </div>
    <div className="table-component__cell--sm">
      Incidence
    </div>     
  </div>
);


const TableRow = ({ info }) => {
  const { date, cases, incidence } = info;
  return (
    <div key={date} className="table-component__row">
      <div className="table-component__cell--sm">
        <div className='table-component__dot'/>
      </div>
      <div className="table-component__cell">
        { date}
      </div>
      <div className="table-component__cell--sm">
        { cases}
      </div>
      <div className="table-component__cell--sm">
        {incidence}
      </div>     
    </div>
  );
};

const renderTableBody = (data) => {  
  if (data) {
    return (
      <div className='table-component__body'>       
        {data.map(datePerDay => <TableRow info={datePerDay} />)}       
      </div>
    );
  }
  return null;  
}

const DataTable = ({ data, loading }) => {  
  return (
    <div className='table-component'>
      {loading ? <div className='table-component__loader-wrapper'><div className='table-component__loader'/></div>:(
        <>
         <TableHeader />
         {renderTableBody(data)}
         </> 
      )}          
    </div>
  )
}

export default DataTable;