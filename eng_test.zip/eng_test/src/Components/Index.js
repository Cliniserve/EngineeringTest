import React, { useState } from "react";
import DataTable from "./Table/Table";
import HeaderView from "./HeaderView/HeaderView";
import { requestData } from "../Logic/logic";

const Index = () => {
  const [requestedData, setRequesteddata] = useState(null);
  const [isLoading,setIsLoading] = useState(false);  

  const handleFilterChange=async(filterLimit)=>{ 
    try {
      const dataResponse = await requestData(filterLimit);
      setRequesteddata(dataResponse); 
      setIsLoading(false);        
    } catch (error) {
      setRequesteddata(null); 
      setIsLoading(false);    
    }   
  }

  return (
    <div className='index-view'>
      <div  className='index-view__wrapper'>
      <HeaderView 
        startLoading={()=>setIsLoading(true)}
        onFilterChange={handleFilterChange}       
       />
      <DataTable data={requestedData} loading={isLoading} />
      </div>
    </div>
  )
}

export default Index;