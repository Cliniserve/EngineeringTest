import './App.css';
import Index from './Components/Index';
function App() {
  return (
    <div className="App">
      <Index/>    
    </div>
  );
}

export default App;
